const COURSES = [
  {
    id: 'python', title: 'Python 从入门到精通', icon: '⌘', category: '编程基础', level: '零基础 → 进阶',
    description: '语法、函数、面向对象、工程实践，并固定加入大模型算法岗代码阅读。',
    tags: ['Python', '算法岗', '逐行中文注释'], colors: ['#5b7cfa', '#33c7d7'],
    modules: [
      ['变量与基本数据类型', '建立最核心的编程表达能力'], ['条件判断与循环', '让程序根据规则自动执行'],
      ['列表、字典与集合', '掌握算法与数据处理常用容器'], ['函数与作用域', '写出可复用、可测试的代码'],
      ['文件、异常与模块', '进入真实项目的代码组织'], ['面向对象编程', '理解类、对象与工程封装'],
      ['Python 工程化', '虚拟环境、日志、测试与规范'], ['算法岗代码阅读', '训练、推理、数据管线常见写法']
    ]
  },
  {
    id: 'pytorch', title: 'PyTorch 与深度学习', icon: '◈', category: 'AI 核心', level: '基础 → 项目',
    description: '张量、自动微分、神经网络、训练循环，以及前沿知识、项目思想与面试题。',
    tags: ['PyTorch', '深度学习', '实战'], colors: ['#f06445', '#f6a65b'],
    modules: [
      ['张量与基本运算', '理解深度学习的数据载体'], ['自动微分 Autograd', '掌握梯度与反向传播'],
      ['构建神经网络', '使用 nn.Module 组织模型'], ['损失函数与优化器', '训练模型的核心机制'],
      ['Dataset 与 DataLoader', '搭建可靠的数据管线'], ['CNN 与视觉任务', '图像特征提取与分类'],
      ['RNN、LSTM 与序列', '理解时序建模'], ['Transformer 基础', '进入现代大模型架构'],
      ['训练工程与调参', '混合精度、早停与实验复现'], ['项目：工业故障分类', '从数据到部署的完整闭环']
    ]
  },
  {
    id: 'llm', title: '大模型与 AI 应用开发', icon: '✦', category: 'AI 核心', level: '基础 → 前沿',
    description: 'Transformer、Prompt、RAG、Agent、评估与部署，每课加入前沿理论和 LeetCode。',
    tags: ['LLM', 'RAG', 'Agent'], colors: ['#7959f5', '#c45df2'],
    modules: [
      ['大语言模型全景', '理解预训练、微调与推理'], ['Transformer 与注意力', '掌握核心公式和数据流'],
      ['Prompt Engineering', '构造稳定、可评估的提示词'], ['Embedding 与向量数据库', '构建语义检索基础'],
      ['RAG 系统', '切分、召回、重排与生成'], ['Agent 与工具调用', '让模型执行多步骤任务'],
      ['模型评估与安全', '质量、幻觉、成本与风险'], ['微调：LoRA / QLoRA', '低成本领域适配'],
      ['推理部署与优化', '量化、缓存、并发与监控'], ['项目：企业知识助手', '可交付的工业级应用']
    ]
  },
  {
    id: 'ml', title: '机器学习体系', icon: '⌁', category: 'AI 核心', level: '基础 → 系统',
    description: '监督学习、无监督学习、特征工程、评估、调参和完整实验方法。',
    tags: ['Scikit-learn', '模型评估', '特征工程'], colors: ['#2bb5a8', '#55d69e'],
    modules: [
      ['机器学习基本范式', '任务、数据、模型与损失'], ['线性与逻辑回归', '建立可解释模型基础'],
      ['决策树与集成学习', 'Random Forest、XGBoost'], ['SVM 与核方法', '最大间隔与非线性映射'],
      ['聚类与降维', 'K-Means、PCA 与表示'], ['特征工程', '缺失、编码、缩放与选择'],
      ['验证与指标', '交叉验证、AUC、F1'], ['调参与实验设计', '网格、贝叶斯与消融']
    ]
  },
  {
    id: 'data', title: 'NumPy、Pandas 与数据分析', icon: '▥', category: '数据能力', level: '零基础 → 实战',
    description: '数组计算、表格处理、清洗、聚合、时间序列与分析报告。',
    tags: ['NumPy', 'Pandas', 'EDA'], colors: ['#1575d1', '#33b5e5'],
    modules: [
      ['NumPy 数组基础', '形状、索引、广播'], ['向量化计算', '替代低效 Python 循环'],
      ['Pandas Series 与 DataFrame', '表格数据核心结构'], ['数据清洗', '缺失值、重复值与异常值'],
      ['筛选、分组与聚合', '回答真实业务问题'], ['合并与重塑', '多表连接和宽长表转换'],
      ['时间序列', '日期索引、窗口和趋势'], ['项目：业务数据分析', '形成可复现分析报告']
    ]
  },
  {
    id: 'sql', title: 'SQL 与数据库', icon: '▤', category: '数据能力', level: '零基础 → 面试',
    description: '查询、连接、聚合、窗口函数、索引、事务与数据库设计。',
    tags: ['SQL', 'MySQL', '窗口函数'], colors: ['#e1a52b', '#e56e4a'],
    modules: [
      ['SELECT 基础查询', '筛选、排序和限制'], ['聚合与分组', 'COUNT、SUM、GROUP BY'],
      ['多表连接', 'INNER、LEFT 与业务关系'], ['子查询与 CTE', '拆解复杂分析逻辑'],
      ['窗口函数', '排名、累计与同比环比'], ['索引与执行计划', '理解查询性能'],
      ['事务与并发', 'ACID、锁和隔离级别'], ['数据库设计', '范式、主键与关系建模']
    ]
  },
  {
    id: 'engineering', title: 'Linux、Git、Docker 与工程基础', icon: '⌬', category: '工程能力', level: '基础 → 部署',
    description: '命令行、版本控制、容器、环境管理、服务部署和团队协作。',
    tags: ['Linux', 'Git', 'Docker'], colors: ['#3c536c', '#2fa1b8'],
    modules: [
      ['Linux 文件与目录', '命令行生存基础'], ['权限、进程与网络', '理解运行环境'],
      ['Shell 与自动化', '用脚本减少重复操作'], ['Git 基础', '提交、分支与回退'],
      ['Git 协作', 'PR、冲突与规范'], ['Docker 核心', '镜像、容器和数据卷'],
      ['Docker Compose', '编排多服务应用'], ['项目部署', '从本地代码到可访问服务']
    ]
  },
  {
    id: 'algorithm', title: '数据结构与基础算法', icon: '⌘', category: '计算机基础', level: '基础 → 面试',
    description: '复杂度、线性结构、树、图、排序、搜索、动态规划和 LeetCode。',
    tags: ['数据结构', '算法', 'LeetCode'], colors: ['#ef5d91', '#a05cf5'],
    modules: [
      ['复杂度分析', '时间与空间复杂度'], ['数组、链表与栈队列', '最常见线性结构'],
      ['哈希表', '高效查找与计数'], ['树与二叉树', '遍历、递归和层序'],
      ['图算法', 'BFS、DFS 与最短路'], ['排序与二分', '经典算法与边界处理'],
      ['贪心与回溯', '局部选择和搜索空间'], ['动态规划', '状态、转移和优化']
    ]
  },
  {
    id: 'recsys', title: '推荐系统', icon: '◎', category: 'AI 专项', level: '基础 → 论文',
    description: '协同过滤、召回、排序、深度推荐、图神经网络与跨领域推荐。',
    tags: ['推荐系统', 'GNN', '召回排序'], colors: ['#e05678', '#f2a359'],
    modules: [
      ['推荐系统全流程', '数据、召回、排序与评估'], ['协同过滤', 'UserCF、ItemCF 与矩阵分解'],
      ['内容推荐', '标签、文本和画像'], ['隐反馈与排序损失', 'BPR、负采样'],
      ['深度推荐模型', 'Wide&Deep、DeepFM'], ['召回系统', '双塔、向量检索与多路召回'],
      ['排序与重排', 'CTR、多目标与多样性'], ['图推荐', 'LightGCN、异构图与社交关系'],
      ['冷启动与跨领域', '迁移、内容和元学习'], ['论文项目', 'Last.fm 异构图音乐推荐']
    ]
  },
  {
    id: 'excel', title: 'Excel 与数据可视化', icon: '▧', category: '数据能力', level: '基础 → 汇报',
    description: '公式、透视表、图表、仪表板，以及 Tableau Public 可视化。',
    tags: ['Excel', 'Tableau Public', 'Dashboard'], colors: ['#208e64', '#5fc074'],
    modules: [
      ['Excel 表格基础', '规范录入与引用'], ['常用函数', '逻辑、查找、文本与日期'],
      ['数据清洗', '分列、去重和 Power Query 思维'], ['数据透视表', '快速聚合与钻取'],
      ['图表表达', '选择正确图形讲故事'], ['仪表板设计', '指标、布局与交互'],
      ['Tableau Public', '连接、维度、度量与发布'], ['项目：分析看板', '形成可展示作品集']
    ]
  },
  {
    id: 'finance', title: '金融、股票与量化基础', icon: '↗', category: '金融能力', level: '零基础 → 进阶',
    description: '金融常识、股票分析、市场情绪、量化交易与机构前沿方法。',
    tags: ['股票', '市场情绪', '量化'], colors: ['#dd8b2e', '#d75855'],
    modules: [
      ['金融市场全景', '资产、机构和交易机制'], ['财务报表基础', '利润、现金流与资产负债'],
      ['估值方法', 'PE、PB、DCF 与相对估值'], ['技术分析基础', '趋势、量价和结构'],
      ['市场情绪', '周期、拥挤与行为偏差'], ['风险与仓位管理', '止损、回撤和组合'],
      ['量化基础', '收益率、因子和回测'], ['机构前沿方法', '另类数据、执行与风控']
    ]
  },
  {
    id: 'cs408', title: '考研 408 长期课程', icon: '▣', category: '计算机基础', level: '零基础 → 高分',
    description: '数据结构、计算机组成、操作系统和计算机网络的两至三年体系。',
    tags: ['408', '数据结构', '操作系统'], colors: ['#5a66d9', '#517ba8'],
    modules: [
      ['数据结构基础', '线性表、树、图和查找排序'], ['计算机组成原理', '数据表示、CPU 与存储'],
      ['操作系统', '进程、内存、文件与 I/O'], ['计算机网络', '分层、协议与网络应用'],
      ['真题专项', '按知识点建立题型模型'], ['综合冲刺', '套卷、错题和时间策略']
    ]
  },
  {
    id: 'project', title: '大模型算法岗项目实战', icon: '⚙', category: '项目实战', level: '作品集 → 入职',
    description: '围绕工业企业场景，完成知识库问答、合同审计、故障分析与部署。',
    tags: ['工业 AI', 'RAG', '作品集'], colors: ['#5b50cc', '#269f97'],
    modules: [
      ['项目 1：企业知识库问答', '文档解析、RAG、引用和评估'], ['项目 2：设备故障智能助手', '日志、故障树和维修建议'],
      ['项目 3：合同与票据审核', '结构化抽取、规则与大模型协同'], ['项目 4：智能数据分析 Agent', '自然语言查询、SQL 和图表'],
      ['工程部署', 'API、Docker、权限与监控'], ['作品集与答辩', 'README、演示、指标和面试表达']
    ]
  }
];

const DEFAULT_TASKS = [
  { id: 'python-lesson', title: 'Python：完成下一课与练习', detail: '重点：先独立写，再对照答案', minutes: 30, course: 'python' },
  { id: 'pytorch-review', title: 'PyTorch：回顾上一课并继续', detail: '整理 3 个核心概念 + 1 段代码', minutes: 35, course: 'pytorch' },
  { id: 'llm-project', title: '项目实战：企业知识库问答', detail: '完成一个可运行的小步骤', minutes: 45, course: 'project' },
  { id: 'algorithm-one', title: '算法：完成 1 道 LeetCode', detail: '写出思路、复杂度和完整代码', minutes: 25, course: 'algorithm' }
];

const STORE = {
  progress: 'qiyun-hub-progress-v1',
  tasks: 'qiyun-hub-tasks-v1',
  notes: 'qiyun-hub-notes-v1',
  theme: 'qiyun-hub-theme-v1',
  sessions: 'qiyun-hub-sessions-v1'
};

const state = {
  progress: loadJSON(STORE.progress, {}),
  tasks: loadJSON(STORE.tasks, DEFAULT_TASKS.map(t => ({...t, done:false}))),
  notes: loadJSON(STORE.notes, []),
  selectedNoteId: null,
  category: '全部',
  search: '',
  timerSeconds: 25 * 60,
  timerHandle: null,
  deferredInstallPrompt: null
};

function loadJSON(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}
function saveJSON(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
function escapeHTML(value='') { return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function courseProgress(course) {
  const completed = new Set(state.progress[course.id] || []);
  return { completed: completed.size, total: course.modules.length, percent: Math.round((completed.size / course.modules.length) * 100) || 0 };
}
function overallStats() {
  const total = COURSES.reduce((n,c) => n + c.modules.length, 0);
  const completed = COURSES.reduce((n,c) => n + courseProgress(c).completed, 0);
  const minutes = state.tasks.filter(t => t.done).reduce((n,t) => n + t.minutes, 0);
  const sessions = Number(localStorage.getItem(STORE.sessions) || 0);
  return { total, completed, percent: Math.round(completed / total * 100) || 0, minutes, sessions };
}
function courseCSS(course) { return `--course-a:${course.colors[0]};--course-b:${course.colors[1]};`; }
function formatDate() {
  return new Intl.DateTimeFormat('zh-CN', { year:'numeric', month:'long', day:'numeric', weekday:'long' }).format(new Date());
}
function greeting() {
  const h = new Date().getHours();
  return h < 6 ? '夜深了' : h < 11 ? '早上好' : h < 14 ? '中午好' : h < 18 ? '下午好' : '晚上好';
}
function toast(message) {
  const el = document.getElementById('toast');
  el.textContent = message; el.classList.add('show');
  clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 2200);
}

function renderStats() {
  const s = overallStats();
  const items = [
    ['综合进度', `${s.percent}%`, `${s.completed} / ${s.total} 个模块`, '◎'],
    ['今日完成', `${state.tasks.filter(t=>t.done).length} 项`, `共 ${s.minutes} 分钟`, '✓'],
    ['课程总数', `${COURSES.length} 门`, '围绕岗位与长期能力', '▦'],
    ['专注次数', `${s.sessions} 次`, '完成的番茄钟', '◷']
  ];
  document.getElementById('statsGrid').innerHTML = items.map(([label,value,sub,icon]) => `
    <article class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><strong>${value}</strong><small>${sub}</small></article>`).join('');
}
function renderContinue() {
  const ranked = [...COURSES].sort((a,b) => {
    const ap = courseProgress(a), bp = courseProgress(b);
    const ar = ap.completed > 0 && ap.completed < ap.total ? 2 : ap.completed === 0 ? 1 : 0;
    const br = bp.completed > 0 && bp.completed < bp.total ? 2 : bp.completed === 0 ? 1 : 0;
    return br - ar || bp.percent - ap.percent;
  }).slice(0,3);
  document.getElementById('continueGrid').innerHTML = ranked.map(course => {
    const p = courseProgress(course);
    const next = course.modules[Math.min(p.completed, course.modules.length - 1)];
    return `<article class="continue-card" data-course="${course.id}" tabindex="0" style="${courseCSS(course)}">
      <div class="continue-cover"><span>${course.icon}</span><small>${course.category}</small></div>
      <div class="continue-body"><h3>${course.title}</h3><p>下一模块：${next[0]}</p><div class="progress-track"><div class="progress-fill" style="width:${p.percent}%"></div></div><div class="progress-meta"><span>${p.completed}/${p.total} 模块</span><span>${p.percent}%</span></div></div>
    </article>`;
  }).join('');
}
function taskHTML(task) {
  return `<label class="task-item ${task.done ? 'completed' : ''}">
    <input class="task-check" type="checkbox" data-task="${task.id}" ${task.done ? 'checked' : ''} />
    <div><strong>${task.title}</strong><small>${task.detail}</small></div><span class="task-time">${task.minutes} min</span>
  </label>`;
}
function renderTasks() {
  const html = state.tasks.map(taskHTML).join('');
  document.getElementById('todayTasks').innerHTML = html;
  document.getElementById('planTasks').innerHTML = html;
  document.getElementById('todayCompletion').textContent = `${state.tasks.filter(t=>t.done).length} / ${state.tasks.length}`;
  document.querySelectorAll('[data-task]').forEach(input => input.addEventListener('change', event => {
    const task = state.tasks.find(t => t.id === event.target.dataset.task);
    if (task) task.done = event.target.checked;
    saveJSON(STORE.tasks, state.tasks); renderAll();
  }));
}
function renderFilters() {
  const categories = ['全部', ...new Set(COURSES.map(c=>c.category))];
  document.getElementById('categoryFilters').innerHTML = categories.map(cat => `<button class="filter-button ${state.category===cat?'active':''}" data-category="${cat}">${cat}</button>`).join('');
  document.querySelectorAll('[data-category]').forEach(btn => btn.addEventListener('click', () => { state.category = btn.dataset.category; renderFilters(); renderCourses(); }));
}
function renderCourses() {
  const query = state.search.trim().toLowerCase();
  const courses = COURSES.filter(c => (state.category === '全部' || c.category === state.category) && (!query || [c.title,c.description,c.category,...c.tags,...c.modules.flat()].join(' ').toLowerCase().includes(query)));
  const grid = document.getElementById('courseGrid');
  grid.innerHTML = courses.length ? courses.map(course => {
    const p = courseProgress(course);
    return `<article class="course-card" data-course="${course.id}" tabindex="0" style="${courseCSS(course)}">
      <div class="course-head"><span class="course-icon">${course.icon}</span><span class="course-level">${course.level}</span></div>
      <h3>${course.title}</h3><p>${course.description}</p>
      <div class="course-tags">${course.tags.map(t=>`<span>${t}</span>`).join('')}</div>
      <div class="progress-track"><div class="progress-fill" style="width:${p.percent}%"></div></div><div class="progress-meta"><span>${p.completed}/${p.total} 模块</span><span>${p.percent}%</span></div>
    </article>`;
  }).join('') : `<div class="empty-state">没有找到匹配课程。换一个关键词试试。</div>`;
  bindCourseCards();
}
function bindCourseCards() {
  document.querySelectorAll('[data-course]').forEach(card => {
    const open = () => openCourse(card.dataset.course);
    card.addEventListener('click', open);
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
  });
}
function openCourse(id) {
  const course = COURSES.find(c=>c.id===id); if (!course) return;
  const completed = new Set(state.progress[course.id] || []), p = courseProgress(course);
  const content = document.getElementById('courseDialogContent');
  content.innerHTML = `<div style="${courseCSS(course)}"><div class="dialog-cover"><span class="course-icon">${course.icon}</span><h2>${course.title}</h2><p>${course.description}</p></div>
    <div class="dialog-body"><div class="section-heading compact"><div><span class="eyebrow">Course Roadmap</span><h3>${p.percent}% 已完成</h3></div><span class="pill">${p.completed} / ${p.total}</span></div>
    <div class="progress-track"><div class="progress-fill" style="width:${p.percent}%"></div></div>
    <div class="module-list">${course.modules.map((m,i)=>`<div class="module-item"><span class="module-number">${String(i+1).padStart(2,'0')}</span><div><strong>${m[0]}</strong><small>${m[1]}</small></div><button class="module-complete ${completed.has(i)?'done':''}" data-module-course="${course.id}" data-module-index="${i}" title="切换完成状态">${completed.has(i)?'●':'○'}</button></div>`).join('')}</div></div></div>`;
  content.querySelectorAll('[data-module-index]').forEach(btn => btn.addEventListener('click', () => {
    const courseId = btn.dataset.moduleCourse, index = Number(btn.dataset.moduleIndex);
    const values = new Set(state.progress[courseId] || []);
    values.has(index) ? values.delete(index) : values.add(index);
    state.progress[courseId] = [...values].sort((a,b)=>a-b);
    saveJSON(STORE.progress, state.progress); openCourse(courseId); renderAll(); toast(values.has(index) ? '模块已标记完成' : '已取消完成状态');
  }));
  document.getElementById('courseDialog').showModal();
}
function renderNotes() {
  const select = document.getElementById('noteCourse');
  select.innerHTML = `<option value="">未分类</option>${COURSES.map(c=>`<option value="${c.id}">${c.title}</option>`).join('')}`;
  if (!state.notes.length) {
    state.notes = [{ id: crypto.randomUUID(), title:'欢迎使用学习笔记', course:'llm', content:'你可以在这里记录：\n\n1. 本节课三个核心概念\n2. 一段自己真正看懂的代码\n3. 一个仍然不懂的问题\n4. 这个知识如何用于项目或面试', updatedAt: Date.now() }];
    saveJSON(STORE.notes, state.notes);
  }
  if (!state.selectedNoteId || !state.notes.some(n=>n.id===state.selectedNoteId)) state.selectedNoteId = state.notes[0].id;
  document.getElementById('notesList').innerHTML = state.notes.slice().sort((a,b)=>b.updatedAt-a.updatedAt).map(note => `<button class="note-list-item ${note.id===state.selectedNoteId?'active':''}" data-note-id="${note.id}"><strong>${escapeHTML(note.title || '无标题笔记')}</strong><small>${new Date(note.updatedAt).toLocaleDateString('zh-CN')} · ${COURSES.find(c=>c.id===note.course)?.title || '未分类'}</small></button>`).join('');
  document.querySelectorAll('[data-note-id]').forEach(btn => btn.addEventListener('click', () => { state.selectedNoteId = btn.dataset.noteId; renderNotes(); loadSelectedNote(); }));
  loadSelectedNote();
}
function loadSelectedNote() {
  const note = state.notes.find(n=>n.id===state.selectedNoteId); if (!note) return;
  document.getElementById('noteTitle').value = note.title || '';
  document.getElementById('noteCourse').value = note.course || '';
  document.getElementById('noteContent').value = note.content || '';
}
function saveSelectedNote() {
  const note = state.notes.find(n=>n.id===state.selectedNoteId); if (!note) return;
  note.title = document.getElementById('noteTitle').value;
  note.course = document.getElementById('noteCourse').value;
  note.content = document.getElementById('noteContent').value;
  note.updatedAt = Date.now(); saveJSON(STORE.notes, state.notes);
  const status = document.getElementById('noteStatus'); status.textContent = '已保存'; clearTimeout(status._timer); status._timer=setTimeout(()=>status.textContent='自动保存',1200);
  renderNotesListOnly();
}
function renderNotesListOnly() {
  document.getElementById('notesList').innerHTML = state.notes.slice().sort((a,b)=>b.updatedAt-a.updatedAt).map(note => `<button class="note-list-item ${note.id===state.selectedNoteId?'active':''}" data-note-id="${note.id}"><strong>${escapeHTML(note.title || '无标题笔记')}</strong><small>${new Date(note.updatedAt).toLocaleDateString('zh-CN')} · ${COURSES.find(c=>c.id===note.course)?.title || '未分类'}</small></button>`).join('');
  document.querySelectorAll('[data-note-id]').forEach(btn => btn.addEventListener('click', () => { state.selectedNoteId=btn.dataset.noteId; renderNotes(); }));
}
function renderProgress() {
  const s = overallStats();
  document.getElementById('progressSummary').innerHTML = [
    ['模块完成率',`${s.percent}%`,`${s.completed}/${s.total}`,'◎'], ['今日投入',`${s.minutes} 分钟`,'按已完成任务计算','◷'], ['已完成课程',`${COURSES.filter(c=>courseProgress(c).percent===100).length} 门`,'达到 100%','✓'], ['笔记数量',`${state.notes.length} 篇`,'本机知识库','✎']
  ].map(([label,value,sub,icon])=>`<article class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><strong>${value}</strong><small>${sub}</small></article>`).join('');
  document.getElementById('progressBars').innerHTML = COURSES.map(c=>{ const p=courseProgress(c); return `<div class="progress-bar-item"><strong>${c.title}</strong><div class="progress-track"><div class="progress-fill" style="width:${p.percent}%"></div></div><span>${p.percent}%</span></div>`; }).join('');
}
function renderAll() { renderStats(); renderContinue(); renderTasks(); renderCourses(); renderProgress(); bindCourseCards(); }
function setView(name) {
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===`${name}View`));
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  const titles = {home:`${greeting()}，启云`,courses:'你的课程体系',plan:'今天学什么',notes:'你的知识库',progress:'你的成长数据'};
  document.getElementById('pageTitle').textContent=titles[name];
  window.scrollTo({top:0,behavior:'smooth'});
}
function setupNavigation() {
  document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>setView(btn.dataset.view)));
  document.querySelectorAll('[data-jump]').forEach(btn=>btn.addEventListener('click',()=>setView(btn.dataset.jump)));
}
function setupTheme() {
  const saved=localStorage.getItem(STORE.theme); if(saved) document.documentElement.dataset.theme=saved;
  document.getElementById('themeToggle').addEventListener('click',()=>{ const next=document.documentElement.dataset.theme==='light'?'dark':'light'; document.documentElement.dataset.theme=next; localStorage.setItem(STORE.theme,next); });
}
function setupSearch() {
  const input=document.getElementById('globalSearch');
  input.addEventListener('input',()=>{ state.search=input.value; renderCourses(); if(input.value.trim()) setView('courses'); });
}
function setupNotes() {
  ['noteTitle','noteCourse','noteContent'].forEach(id=>document.getElementById(id).addEventListener('input',saveSelectedNote));
  document.getElementById('newNoteButton').addEventListener('click',()=>{ const note={id:crypto.randomUUID(),title:'新笔记',course:'',content:'',updatedAt:Date.now()}; state.notes.unshift(note); state.selectedNoteId=note.id; saveJSON(STORE.notes,state.notes); renderNotes(); document.getElementById('noteTitle').focus(); });
  document.getElementById('deleteNoteButton').addEventListener('click',()=>{ if(state.notes.length<=1){ toast('至少保留一篇笔记'); return; } state.notes=state.notes.filter(n=>n.id!==state.selectedNoteId); state.selectedNoteId=state.notes[0]?.id; saveJSON(STORE.notes,state.notes); renderNotes(); toast('笔记已删除'); });
}
function setupTimer() {
  const display=document.getElementById('timerDisplay'), start=document.getElementById('timerStart');
  const update=()=>{ const m=Math.floor(state.timerSeconds/60),s=state.timerSeconds%60; display.textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; };
  start.addEventListener('click',()=>{ if(state.timerHandle){ clearInterval(state.timerHandle); state.timerHandle=null; start.textContent='继续'; return; } start.textContent='暂停'; state.timerHandle=setInterval(()=>{ state.timerSeconds--; update(); if(state.timerSeconds<=0){ clearInterval(state.timerHandle); state.timerHandle=null; state.timerSeconds=25*60; localStorage.setItem(STORE.sessions,String(Number(localStorage.getItem(STORE.sessions)||0)+1)); update(); renderStats(); start.textContent='开始'; toast('完成一次 25 分钟专注学习！'); } },1000); });
  document.getElementById('timerReset').addEventListener('click',()=>{ clearInterval(state.timerHandle);state.timerHandle=null;state.timerSeconds=25*60;start.textContent='开始';update(); }); update();
}
function setupDataActions() {
  document.getElementById('exportButton').addEventListener('click',()=>{ const data={version:1,exportedAt:new Date().toISOString(),progress:state.progress,tasks:state.tasks,notes:state.notes,sessions:Number(localStorage.getItem(STORE.sessions)||0)}; const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a');a.href=url;a.download=`qiyun-learning-data-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url);toast('学习数据已导出'); });
  document.getElementById('importInput').addEventListener('change',async e=>{ const file=e.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());state.progress=data.progress||{};state.tasks=data.tasks||DEFAULT_TASKS;state.notes=data.notes||[];localStorage.setItem(STORE.sessions,String(data.sessions||0));saveJSON(STORE.progress,state.progress);saveJSON(STORE.tasks,state.tasks);saveJSON(STORE.notes,state.notes);renderAll();renderNotes();toast('学习数据已导入');}catch{toast('导入失败：文件格式不正确');}e.target.value=''; });
  document.getElementById('resetToday').addEventListener('click',()=>{ state.tasks=DEFAULT_TASKS.map(t=>({...t,done:false}));saveJSON(STORE.tasks,state.tasks);renderAll();toast('今日任务已重置'); });
}
function setupInstall() {
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();state.deferredInstallPrompt=e;});
  document.getElementById('installButton').addEventListener('click',async()=>{ if(state.deferredInstallPrompt){state.deferredInstallPrompt.prompt();await state.deferredInstallPrompt.userChoice;state.deferredInstallPrompt=null;} else document.getElementById('installDialog').showModal(); });
}
function registerServiceWorker() { if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{}); }

document.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('todayLabel').textContent=formatDate(); document.getElementById('pageTitle').textContent=`${greeting()}，启云`;
  setupNavigation();setupTheme();setupSearch();renderFilters();renderNotes();setupNotes();setupTimer();setupDataActions();setupInstall();renderAll();registerServiceWorker();
});
