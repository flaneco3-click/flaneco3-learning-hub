# 启云学习站 · Qiyun Learning Hub

这是一个无后端、零依赖的个人学习 PWA，可直接部署到任意静态网站托管服务。

## 已包含

- 13 门个性化课程路线
- 课程模块与完成进度
- 今日学习计划
- 25 分钟专注计时
- 本地学习笔记
- 学习数据导出/导入
- 明暗模式
- iPhone Safari 添加到主屏幕
- Service Worker 离线缓存

## 本地预览

直接双击 `index.html` 可以查看大部分功能。离线缓存/PWA 安装需要通过 HTTP/HTTPS 访问。

使用 Python 本地服务：

```bash
python -m http.server 8080
```

然后访问 `http://localhost:8080`。

## 发布成公网网址

最简单方式之一：

1. 将整个文件夹上传到 GitHub 仓库。
2. 在仓库 Settings → Pages 中选择从主分支根目录发布。
3. 发布后会得到类似 `https://你的用户名.github.io/仓库名/` 的地址。
4. 在 iPhone Safari 打开该地址，点击分享 → 添加到主屏幕。

也可以把整个文件夹拖到支持静态站点发布的平台（例如 Cloudflare Pages 或 Netlify）。

## 数据说明

课程进度、任务和笔记默认保存在浏览器 `localStorage` 中，不会上传到服务器。更换设备前请点击左侧“导出”按钮备份 JSON，再在新设备导入。

## 后续升级建议

- 登录与多设备云同步
- 后台课程编辑器
- 接入大模型导师（必须使用服务端保护 API Key）
- 每课完整正文、练习和答案
- 学习提醒与日历联动
- 自定义域名，例如 `learn.hanqiyun.com`
